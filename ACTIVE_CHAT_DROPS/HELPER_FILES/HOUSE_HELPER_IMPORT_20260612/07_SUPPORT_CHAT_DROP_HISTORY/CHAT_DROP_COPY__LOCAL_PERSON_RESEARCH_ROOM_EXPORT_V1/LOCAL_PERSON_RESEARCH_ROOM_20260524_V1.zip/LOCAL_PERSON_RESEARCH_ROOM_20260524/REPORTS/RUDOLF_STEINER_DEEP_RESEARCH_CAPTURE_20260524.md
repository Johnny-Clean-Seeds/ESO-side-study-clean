# Rudolf Steiner Deep Research Capture

Date: 2026-05-24
Status: local-only source ore.
Git: do not commit.

## Short Verdict

Steiner has the most usable "build" material of the three, but also the highest authority risk. He is a whole-system builder: he turns worldview into school, farm, medicine, architecture, art, movement, curriculum, ritual, and institution.

His cleanest gifts:

- Goethean observation
- living-form thinking
- development and timing
- form shapes function
- art as cognition
- institution embodiment
- farm/body/society as organism
- sphere separation
- practice-result versus metaphysical-claim split

His danger:

- clairvoyance as evidence
- founder insight as institution authority
- race and cultural hierarchy material
- medicine without sufficient evidence
- biodynamic cosmic mechanisms treated as science
- hidden esoteric roots inside practical institutions
- aesthetic coherence mistaken for truth

Clean conclusion:

Steiner is a powerful organism lens and institution-design warning case. Use the method-level lens. Quarantine the oracle.

## What The Existing Steiner Files Had

The revised Steiner file and later research paper were already good. They correctly split method from claim, practical result from metaphysical explanation, and whole-system insight from authority inflation.

What this pass strengthens:

- direct build import list
- stronger "why Steiner seems useful to us" explanation
- clearer use of Steiner against our current house problem: too many parts, not enough living-form stage timing
- more explicit evidence split across education, agriculture, medicine, architecture, and social theory

## Life Map

Steiner was born in 1861 in Kraljevec, then in the Austrian Empire, now in Croatia, and died in 1925 in Dornach, Switzerland. The Rudolf Steiner Archive timeline emphasizes the railway childhood: rural landscape plus industrial telegraph/rail infrastructure. He later studied mathematics, natural science, philosophy, literature, and Goethe. He edited Goethe's scientific writings, published The Philosophy of Freedom, joined and then broke from Theosophy, formed anthroposophy, built the Goetheanum, guided Waldorf education, biodynamic agriculture, anthroposophic medicine, eurythmy, and social threefolding.

The life sequence:

1. Railway childhood: machine and field side by side.
2. Goethe studies: living form and metamorphosis.
3. Philosophy of freedom: conscious thinking and ethical individualism.
4. Theosophy: esoteric vocabulary and danger inheritance.
5. Anthroposophy: one total worldview.
6. Goetheanum: worldview into building.
7. Waldorf: worldview into education.
8. Biodynamics: worldview into farming.
9. Medicine/eurythmy/social theory: worldview into body, movement, and institution.

Build note:

Steiner matters because he shows how an idea becomes habitat. That is exactly what the house is doing. The warning is that habitat can make unproven claims feel true.

## Major Idea Taxonomy

### 1. Goethean Observation

Goethean observation studies living form over time. It resists dead snapshots. A plant, child, farm, rule, assistant, or house cannot be understood only by cutting it into parts.

Build use:

Living Form Observation Cycle:

- observe the object in time
- note stages
- note rhythm
- note environment
- note metamorphosis
- delay final category until enough movement is seen

Misuse:

Do not use "living form" to avoid precise evidence.

### 2. Thinking As Practice

The Philosophy of Freedom gives the clean early Steiner: freedom comes from awake thinking and conscious motive, not mere impulse or obedience.

Build use:

Before calling an action free, ask whether it is conscious, placed, and owned.

Misuse:

Do not use freedom language to justify drift.

### 3. Developmental Timing

Waldorf education's strongest practical signal is timing: stage matters. The same input can be good or bad depending on developmental phase.

Build use:

Stage-Time Check:

- is this object in seed, loop, failure, recovery, practical use, or final wrap?
- are we forcing final polish onto a seed?
- are we keeping a mature object in baby mode?

Misuse:

Do not treat exact seven-year schemes or subtle-body claims as modern developmental science.

### 4. Form Shapes Function

Steiner's architecture, eurythmy, classroom design, color, rhythm, and ritual all say: form trains behavior.

Build use:

Rooms, filenames, order, templates, rhythm, and visual layout change how work happens.

Misuse:

A beautiful form can still carry a false claim.

### 5. Art As Cognition

For Steiner, art is not decoration. Gesture, color, movement, speech, and drama are ways of knowing and forming.

Build use:

The house can use diagrams, room names, cards, and embodied routines when they improve perception.

Misuse:

Do not let beauty replace proof.

### 6. Farm As Organism

Biodynamics is risky, but the farm-organism idea is clean source ore: soil, animals, plants, compost, farmer, place, rhythm, and fertility are one system.

Build use:

House-as-organism map:

- rooms are organs
- receipts are circulation
- notes are nerve signals
- Git is skeleton/archive
- washer is metabolic clean-up
- TODO is immune response only when scoped

Misuse:

Do not import cosmic mechanisms as fact.

### 7. Practical Result Versus Metaphysical Explanation

This is the most important Steiner washer rule.

A Waldorf classroom may work because of teacher attention, rhythm, art, and relationship, not because every anthroposophical claim is true.

A biodynamic farm may improve soil because of compost, biodiversity, and care, not because cosmic preparation mechanisms are proven.

A medical practice may comfort a patient, but that does not establish treatment efficacy.

Build use:

Evidence Split Rule:

```text
observable result != proof of founding metaphysics
```

Misuse:

Do not launder weak claims through practical outcomes.

### 8. Social Threefolding

Steiner's social threefolding separates cultural/spiritual life, rights/political life, and economic life. The clean idea is that one sphere should not colonize all others.

Build use:

House Sphere Check:

- truth/proof lane
- creative/source-ore lane
- operations/save lane
- user-direction lane

Do not let one lane swallow the rest.

Misuse:

Not a proven political system.

### 9. Institution Embodiment

Steiner's ideas became schools, farms, buildings, medicine, products, religious communities, and care communities.

Build use:

When a rule is strong, ask what institution or habit carries it:

- card
- room
- schedule
- receipt
- gate
- template
- training stage

Misuse:

An institution can preserve error as easily as truth.

### 10. Source Corpus Care

Steiner has a vast lecture corpus, often mediated by shorthand, editing, translation, and movement institutions.

Build use:

No isolated quote without source type, edition, date, translation, and context.

Misuse:

No quote-mining.

## Applied Lanes

### Waldorf Education

Usable:

- developmental pacing
- whole-child attention
- rhythm
- story and imagination
- handwork and embodiment
- teacher self-development
- art integrated into learning

Quarantine:

- hidden anthroposophical metaphysics
- racial/cultural-stage material
- exact subtle-body anthropology as science
- opaque parent communication
- vaccine/medical spillovers where present

### Biodynamic Agriculture

Usable:

- farm as organism
- soil health
- compost
- biodiversity
- closed loops
- farmer attention
- seasonal rhythm

Quarantine:

- cosmic-force mechanisms
- horn/preparation claims as established science
- astrology as proof
- treating organic/ecological benefits as proof of occult mechanism

### Anthroposophic Medicine

Usable:

- whole-person care as human care
- warmth, rhythm, biography, relationship
- supportive context if medically safe

Quarantine:

- treatment claims without medical-grade evidence
- mistletoe claims outside evidence limits
- replacement of conventional medicine
- hidden metaphysics in informed consent

### Goetheanum / Architecture

Usable:

- room as teaching force
- architecture as embodied worldview
- form shapes attention

Quarantine:

- monument makes doctrine feel inevitable

### Eurythmy And Movement

Usable:

- movement as language
- gesture can carry cognition

Quarantine:

- therapy or medical claims without evidence

## Main Controversies And Guardrails

### Race And Cultural Hierarchy

Serious critical scholarship argues that racial and cultural-evolutionary hierarchy is not incidental in Steiner's corpus. Defenders argue context and individualism. Clean handling: no race/culture material enters as authority.

### Medicine

NCI and other medical evidence sources require caution around mistletoe and anthroposophic medicine. Medical claims are high-stakes and need medical-grade evidence.

### Biodynamics

Research reviews show biodynamic systems can perform well compared with conventional agriculture, but distinct biodynamic mechanisms remain unclear and may not outperform organic approaches.

### Hidden Institution Roots

If a school, farm, clinic, or practice has anthroposophical roots, trust requires transparency.

### Founder Canon

The biggest movement risk is treating Steiner's statements as final because the institution is built around him.

## Clean Build Imports

1. Living Form Observation Cycle

Watch an object across time before deciding final category.

2. Stage-Time Check

Match pressure to developmental phase.

3. Form Shapes Function Rule

Design rooms, cards, names, and routines because they train behavior.

4. Evidence Split Rule

Practical result does not prove founding metaphysics.

5. Institution Carrier Map

Every useful rule needs a carrier, and every carrier needs a warning against freezing into doctrine.

6. Sphere Separation

Keep creative source, proof, operation, and authority lanes distinct.

7. Co-Carrier Rule

Track collaborators and downstream carriers. Do not make every movement a one-man statue.

8. Corpus-Care Rule

Large lecture/source bodies need edition, translation, context, and source-type checks.

## Blocked Imports

- clairvoyance as proof
- race hierarchy
- cultural-stage doctrine
- medical authority
- science authority
- hidden metaphysics
- founder obedience
- aesthetic proof
- quote-mined lecture authority

## Strongest Conclusion

Steiner is the most dangerous useful source here. He can teach the house how living forms become institutions, how stages need timing, how rooms teach, and how a system can be more than a pile. But he also shows exactly how one person's worldview can inflate across too many lanes.

Best house use:

Use Steiner for living-form, development, form-function, and institution-carrier design.

Do not use Steiner for science, medicine, race, authority, or proof.

