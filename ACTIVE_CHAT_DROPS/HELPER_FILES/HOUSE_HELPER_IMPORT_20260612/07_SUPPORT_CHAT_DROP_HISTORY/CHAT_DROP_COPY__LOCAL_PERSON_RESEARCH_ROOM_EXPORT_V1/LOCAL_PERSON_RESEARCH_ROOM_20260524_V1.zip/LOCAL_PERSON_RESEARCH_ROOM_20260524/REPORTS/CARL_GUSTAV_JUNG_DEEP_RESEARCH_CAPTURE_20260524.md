# Carl Gustav Jung Deep Research Capture

Date: 2026-05-24
Status: local-only source ore.
Git: do not commit.

## Short Verdict

Jung is the strongest of the three for "shadow" work in this build. His best tools are not predictions or mystical proof. They are integration tools:

- hidden complex detection
- projection return
- persona versus real-state checks
- shadow placement
- symbolic reading with proof boundaries
- dream/image source ore
- active imagination with grounding
- individuation as placing split parts correctly

His danger is symbolic inflation:

- image becomes proof
- coincidence becomes command
- archetype becomes biology
- gender type becomes doctrine
- race/culture language becomes hierarchy
- Jung becomes oracle

Clean conclusion:

Use Jung as a depth-mapping lens. Keep a hard proof gate outside the symbol room.

## What The Existing Jung File Had

The revised Jung file is already strong. It correctly names the high-value/high-risk structure, tracks the Red Book and Black Books, includes co-carriers, and warns around race, gender, Nazi-era controversy, synchronicity, and clinical evidence limits.

What this pass strengthens:

- the "how to use this in the build" layer
- distinction between meaning and proof
- the connection between Jung and the transcript files on synchronicity, frame, identity, and unconscious scripts
- the shadow/projection/complex routine as a working washer

## Life Map

Jung was born in Switzerland in 1875 and died in 1961. The Library of Congress places his roots in a Protestant family line, early fascination with dream and invisible phenomena, medical training at Basel, work at Burgholzli under Eugen Bleuler, word-association research, complex theory, Freud alliance, Freud split, and the Red Book period.

The deep sequence:

1. Religious family and inner experience create the religion problem.
2. Medicine and psychiatry put him inside real suffering, psychosis, and speech disturbance.
3. Word association gives him a measurable entrance into emotional knots.
4. Freud gives him unconscious theory and a father-system to both inherit and break.
5. The Freud split opens the Red Book descent.
6. Active imagination becomes self-experiment.
7. Analytical psychology becomes system, school, institution, and archive.

Build note:

Jung is a descent-and-return thinker. If the descent never returns to proof and placement, it becomes fog.

## Major Idea Taxonomy

### 1. Ego Is Not The Whole House

The ego is the center of consciousness, not the entire psyche. In house language: the active guide, current user request, bot output, or surface emotion is not automatically the whole system.

Build use:

Before acting on a loud surface signal, ask what is outside conscious view.

Misuse:

Do not use "the unconscious knows" as authority.

### 2. Complexes Are Emotional Knots

Jung's complex theory comes from clinical and word-association roots. A complex behaves like a hidden boss: repeated charge, distortion, compulsion, and timing collapse.

Build use:

Complex Voltage Check:

- what keeps repeating?
- where does the system overreact?
- what topic changes tone?
- where do notes get loud without new proof?
- what path keeps returning?

Misuse:

Do not literalize every knot as a separate entity.

### 3. Projection Return

Projection means the outside object carries something the inside has not owned.

Build use:

When blaming a file, agent, rule, room, or person, ask:

- what is actually outside?
- what is being projected?
- what evidence separates them?
- what belongs back in our system?

Misuse:

Projection checks do not erase real external problems.

### 4. Shadow

Shadow is what the ego refuses to recognize. It can be shame, anger, weakness, envy, need, laziness, desire, fear, or even a rejected gift.

Build use:

House shadow walk:

- find what the house avoids seeing
- find what the house over-condemns
- find what the house calls trash
- find what the house cannot place

Misuse:

Shadow work is not a pass for bad behavior.

### 5. Persona

Persona is the social mask or role. It is needed, but becomes dangerous when mistaken for the whole being.

Build use:

Assistant persona check:

- are we acting helpful or actually helping?
- are we sounding wise or proving route?
- is the "suit" serving the task or performing identity?

Misuse:

No fake role-play as truth.

### 6. Anima / Animus / Inner Other

Jung's original gendered model is historically important and modernly hazardous. For this build, translate cautiously as "inner other," "missing mode," or "projected complement."

Build use:

Ask what missing style of intelligence the system projects outward.

Misuse:

No gender doctrine. No essentialism.

### 7. Archetypes

Archetypes are recurring pattern forms in Jung's model. They are useful for seeing deep story shapes but weak as settled biology.

Build use:

Use archetype language as pattern shorthand only:

- teacher
- shadow
- trickster
- child
- old wise figure
- descent
- rebirth
- tower

Misuse:

Archetype is not evidence.

### 8. The Self And Individuation

The Self in Jung's model is the regulating whole. Individuation is not self-indulgent individualism; it is integration and differentiation.

Build use:

House individuation means rooms become distinct without losing relation.

Misuse:

Do not confuse "whole-system center" with "I am special."

### 9. Dreams And Images

Jung treats dreams as compensatory and symbolic. A dream or image may point to what conscious attitude ignores.

Build use:

When a metaphor keeps appearing, ask what it compensates for.

Misuse:

No dream dictionary. No prophecy.

### 10. Active Imagination

Active imagination is structured engagement with inner figures/images. It is powerful but needs grounding.

Build use:

Creative room can do active-imagination style work if it has:

- entry question
- boundary
- notes
- return route
- proof gate

Misuse:

No inner image gets command authority.

### 11. Synchronicity

The Jung transcript explains synchronicity as meaningful connection without ordinary cause. It also warns against shallow "number sign" thinking and grandiosity.

Build use:

Synchronicity Quarantine:

- record the pattern
- mark meaning
- do not act as proof
- seek independent evidence
- watch grandiosity

Misuse:

Coincidence can invite investigation. It cannot close a gate.

### 12. Alchemy

Jung reads alchemy as a symbolic transformation map. Nigredo, separation, coniunctio, vessel, and transformation are useful metaphors for process.

Build use:

The washer is alchemical only as metaphor: dirty input, vessel, heat, separation, clean output.

Misuse:

Do not literalize alchemy or use it as science.

### 13. Religion As Psychic Fact

Jung does not require a religious symbol to be metaphysically proven before it matters psychologically. A symbol can be active in the psyche.

Build use:

House symbols can have real routing force even when they are metaphors.

Misuse:

Psychic reality is not the same as external proof.

### 14. Typology

Introversion/extraversion and functions can help notice preferred modes. MBTI is downstream and not identical to Jung.

Build use:

Use as soft mode labels, not identity cages.

Misuse:

No type determinism.

## Main Controversies And Guardrails

### Empirical Limits

Jungian psychotherapy has some supportive outcome evidence, but reviews still call for stronger randomized controlled trial designs. Use with respect, not overclaim.

### Race And Colonial Material

The IAAP apology confirms that Jung's race-related writings caused harm and require explicit warning. This material does not enter the house as authority.

### Nazi-Era Complexity

Jung's 1930s entanglements and later OSS contact make a complicated historical object. Complexity is not exoneration. Keep both.

### Gender Essentialism

Anima/animus language should not become doctrine.

### Guru Risk

The Red Book and Black Books make Jung deeper, not infallible.

## Clean Build Imports

1. Shadow Before Blame

Before assigning blame outside, check projection and shadow.

2. Complex Voltage Ledger

Repeated emotional charge marks a knot needing placement.

3. Persona Versus Real-State Check

Ask whether the role is helping or only performing.

4. Symbol Not Proof Rule

Images can open inquiry. Evidence closes gates.

5. Synchronicity Quarantine

Meaningful coincidence gets a note, not authority.

6. Inflation Alarm

If insight produces chosen-ness, specialness, or grandiosity, stop and ground.

7. Co-Carrier Rule

Track collaborators, editors, patients, students, and institutions. No one-person myth if many carried the work.

## Blocked Imports

- diagnosis
- therapy replacement
- dream prophecy
- synchronicity proof
- race/culture authority
- gender doctrine
- archetypes as settled biology
- guru obedience
- symbolic command

## Strongest Conclusion

Jung is the best source here for finding the thing "in the shadows." But his method must be washed before use. The house can use his shadow, complex, persona, projection, and individuation lenses right now. It must keep synchronicity, archetypes, active imagination, and alchemy behind warning glass until proof and placement are clear.

Best house use:

Use Jung when the house feels haunted by repeated charge, projection, identity performance, symbolic clutter, or a missing part.

Do not use Jung when the house needs empirical proof, medical decisions, final authority, or a simple operational route.

