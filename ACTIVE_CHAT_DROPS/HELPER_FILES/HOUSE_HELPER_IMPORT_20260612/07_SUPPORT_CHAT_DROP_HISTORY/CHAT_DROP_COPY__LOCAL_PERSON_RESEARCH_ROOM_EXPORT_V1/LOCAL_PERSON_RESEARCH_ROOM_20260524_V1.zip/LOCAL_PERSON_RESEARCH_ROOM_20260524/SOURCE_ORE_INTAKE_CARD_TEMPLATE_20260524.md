# Source Ore Intake Card Template

Date: 2026-05-24
Status: local-only working template.
Git: do not commit source/person/transcript cards unless later distilled into a neutral house rule.

## Purpose

Use this card for any person, transcript, philosophy, outside idea, or strange source before it is allowed to affect the house.

The card keeps the rope tight:

- save the source
- name the clean gift
- name the dirty risk
- separate method from claim
- scale note weight
- burn dead weight into storage or a smaller rule

## Card

### 1. Source Identity

Source name:

Source type:

Local path or link:

Date read:

Why it entered the house:

### 2. First Read

Main subject:

Strongest useful idea:

Most suspicious or risky idea:

What felt alive:

What felt like bloat:

### 3. Four-Layer Split

Biography:

Method:

Claim:

Authority request:

Washer check:

Most useful sources should enter through method, not authority.

### 4. Evidence Gate

Evidence strength:

Evidence type:

What is directly shown:

What is only inferred:

What would need stronger proof:

Blocked claim:

### 5. Build Translation

Clean house question:

Possible rule:

Possible routine:

Possible room or folder placement:

Smallest useful carrier:

### 6. Note Weight Scaling

Weight level:

- 0 = parked only
- 1 = interesting note
- 2 = repeated pattern
- 3 = active problem match
- 4 = proved useful in work
- 5 = belongs in a neutral house rule

Loudness rule:

A note may get louder only when weight increases through repeated usefulness, direct problem fit, or proof in work. Time alone can raise review priority, but not truth authority.

Time rule:

If a note ages without being used, it should ask for review, not automatic promotion.

### 7. Tug Rule

When to tug the rope:

- contradiction appears
- source starts becoming doctrine
- note weight rises without proof
- same pattern appears in multiple rooms
- active work gets foggy

Tug action:

Trace the idea back to source, method, evidence, and current house need.

### 8. Burn Rule

Burn does not mean delete.

Burn means remove live weight and place cleanly.

Burn into:

- archive
- source ledger
- parking lot
- rejected claim list
- later review TODO
- distilled neutral rule

Burn triggers:

- no active use after review
- duplicate note
- vibes without method
- authority without evidence
- quote without source
- metaphor that starts acting like proof

### 9. Runner Trace

If a note is cut from the active rope, leave a runner trace.

Root source:

Rule or folder it links to:

Reason it was cut:

Where it can be found later:

Condition for reopening:

### 10. Final Verdict

Verdict:

- bring forward
- park local
- archive only
- reject claim
- needs another source
- needs practical test

Next action:

Owner or room:

Review date:

