# Transcript Custody Copy - 2026-05-25

Purpose: keep the transcript source files physically inside the local person research room instead of only pointing back to the larger project copy.

## Copied Source Trees

Clean/package transcript tree copied from:

- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\YT_TRANSCRIPTS

Raw SRT transcript tree copied from:

- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\MULE_LOCAL_ONLY\ROOT_TANSCRIPTS_LOCAL_ONLY_20260524_100700

Later ET0 transcript drop copied from:

- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\SOURCE_ORE\USER_DROPS\ROOT_DROP_ET0O9ZL3BDS_TRANSCRIPT_SET_20260524_220844

Local custody root:

- C:\Users\13527\Desktop\123\LOCAL_PERSON_RESEARCH_ROOM_20260524\TRANSCRIPT_FILES

## Verification

- Clean/package tree: 61 source files, 61 local files, 0 missing relative paths, 0 SHA256 mismatches.
- Raw SRT tree: 14 source files, 14 local files, 0 missing relative paths, 0 SHA256 mismatches.
- Later ET0 drop: 4 source files, 4 local files, 0 missing relative paths, 0 SHA256 mismatches.
- Old transcript manifest surfaces covered: repo-current-yt-transcripts 61 files, root-local-tanscripts 14 files.

## Notes

- Folder structure is preserved by video ID.
- Transcript chunks, clean full transcripts, raw SRT/VTT captions, receipts, source intake notes, local archive packages, and related transcript package files were copied together.
