# Source Ledger

Date: 2026-05-24
Status: local-only source ledger.

## Local Files Read

### Alan Watts

- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\MULE_OUTBOX\ALAN_WILSON_WATTS_DIGITAL_JAR_DEEP_EXPANSION_20260522\ALAN_WILSON_WATTS_DIGITAL_JAR_DEEP_EXPANSION_RETURN_20260522.md
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\MULE_OUTBOX\ALAN_WILSON_WATTS_DIGITAL_JAR_DEEP_EXPANSION_20260522\ALAN_WILSON_WATTS_SOURCE_MAP_20260522.md
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\MULE_OUTBOX\ALAN_WILSON_WATTS_DIGITAL_JAR_DEEP_EXPANSION_20260522\ALAN_WILSON_WATTS_GAP_MAP_AGAINST_123_ROOT_PAPER_20260522.md
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\MULE_OUTBOX\ALAN_WILSON_WATTS_DIGITAL_JAR_DEEP_EXPANSION_20260522\ALAN_WILSON_WATTS_GOODIE_BAG_20260522.md
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\MULE_OUTBOX\ALAN_WILSON_WATTS_DIGITAL_JAR_DEEP_EXPANSION_20260522\ALAN_WILSON_WATTS_DEEP_EXPANSION_RECEIPT_20260522.txt

### Carl Gustav Jung

- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\SOURCE_TRANSFER\MD_INCOMING\CARL_GUSTAV_JUNG_DIGITAL_JAR_DEEP_RESEARCH_REVISED_20260522.md
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\SOURCE_TRANSFER\MD_INCOMING\CARL_GUSTAV_JUNG_DIGITAL_JAR_DEEP_RESEARCH_20260522.md

### Rudolf Steiner

- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\SOURCE_TRANSFER\MD_INCOMING\RUDOLF_STEINER_DIGITAL_JAR_DEEP_RESEARCH_REVISED_20260522.md
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\SOURCE_TRANSFER\MD_INCOMING\RUDOLF_STEINER_DIGITAL_JAR_DEEP_RESEARCH_20260522.md
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\RESEARCH_PACKETS\RUDOLF_STEINER_20260523\RUDOLF_STEINER_DEEP_DIVE_RESEARCH_PAPER_V0_1.md
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\RESEARCH_PACKETS\RUDOLF_STEINER_20260523\RUDOLF_STEINER_DEEP_DIVE_RESEARCH_NOTES_V0_1.md

### Transcripts

- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\YT_TRANSCRIPTS\6LP3n9V7H_8\TRANSCRIPT_CLEAN_FULL_6LP3n9V7H_8.txt
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\YT_TRANSCRIPTS\Dgbci0GC1vk\TRANSCRIPT_CLEAN_FULL_Dgbci0GC1vk.txt
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\YT_TRANSCRIPTS\ET0o9zL3BDs\TRANSCRIPT_CLEAN_REPAIRED_ET0o9zL3BDs.txt
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\YT_TRANSCRIPTS\Hm9ADZ28Wgo\TRANSCRIPT_CLEAN_FULL_Hm9ADZ28Wgo.txt
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\YT_TRANSCRIPTS\vH0njQMF_gc\TRANSCRIPT_CLEAN_FULL_vH0njQMF_gc.txt
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\YT_TRANSCRIPTS\w4HWSqnnzEo\TRANSCRIPT_CLEAN_FULL_w4HWSqnnzEo.txt
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\YT_TRANSCRIPTS\Wn-qgHg5JhE\TRANSCRIPT_CLEAN_FULL_Wn-qgHg5JhE.txt
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\YT_TRANSCRIPTS\YvyUdcVk_gA\TRANSCRIPT_CLEAN_FULL_YvyUdcVk_gA.txt
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\YT_TRANSCRIPTS\ZtOxCJqEHjY\TRANSCRIPT_CLEAN_FULL_ZtOxCJqEHjY.txt
- C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\YT_TRANSCRIPTS\ZtOxCJqEHjY\USER_PULLED_NOTES_ZtOxCJqEHjY.txt

Local custody copy added 2026-05-25:

- C:\Users\13527\Desktop\123\LOCAL_PERSON_RESEARCH_ROOM_20260524\TRANSCRIPT_FILES\YT_TRANSCRIPTS
- Source tree copied from C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\YT_TRANSCRIPTS
- Verification after copy: 61 source files, 61 local files, 0 missing relative paths, 0 SHA256 mismatches.
- C:\Users\13527\Desktop\123\LOCAL_PERSON_RESEARCH_ROOM_20260524\TRANSCRIPT_FILES\ROOT_TANSCRIPTS_LOCAL_ONLY_20260524_100700
- Source tree copied from C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\MULE_LOCAL_ONLY\ROOT_TANSCRIPTS_LOCAL_ONLY_20260524_100700
- Verification after copy: 14 source files, 14 local files, 0 missing relative paths, 0 SHA256 mismatches.
- C:\Users\13527\Desktop\123\LOCAL_PERSON_RESEARCH_ROOM_20260524\TRANSCRIPT_FILES\ROOT_DROP_ET0O9ZL3BDS_TRANSCRIPT_SET_20260524_220844
- Source tree copied from C:\Users\13527\Desktop\123\Jxhnny_Kl33N_Seedz\SOURCE_ORE\USER_DROPS\ROOT_DROP_ET0O9ZL3BDS_TRANSCRIPT_SET_20260524_220844
- Verification after copy: 4 source files, 4 local files, 0 missing relative paths, 0 SHA256 mismatches.

### Root Drop Chat Sources

- C:\Users\13527\Desktop\123\LOCAL_PERSON_RESEARCH_ROOM_20260524\SOURCE_SNAPSHOTS\ROOT_DROP_ChatBots_20260524.txt

## Web Sources Used

### Alan Watts

- Alan Watts Organization biography: https://alanwatts.org/biography
- Alan Watts Organization books and articles: https://alanwatts.org/books-articles
- Alan Watts Organization archive story: https://alanwatts.org/our-story
- Tricycle, Alan Watts Reconsidered: https://tricycle.org/magazine/alan-watts-reconsidered/
- Tricycle, The Sensualist: https://tricycle.org/magazine/sensualist/
- Self & Society, Psychotherapy East and West retrospective review: https://www.tandfonline.com/doi/full/10.1080/03060497.2016.1142261

### Carl Jung

- Library of Congress, Before the Red Book: https://www.loc.gov/exhibits/red-book-of-carl-jung/before-the-red-book.html
- Philemon Foundation, The Black Books: https://philemonfoundation.org/works/black-books/
- Philemon Foundation, Jaffe interview protocols: https://philemonfoundation.org/works/the-original-protocols-for-memories-dreams-reflections/
- PubMed, Jungian psychotherapy evidence base: https://pubmed.ncbi.nlm.nih.gov/34881942/
- IAAP acknowledgement/apology on race material: https://pgiaa.org/wp-content/uploads/2017/04/IAAP-acknowledgement_apology.pdf

### Rudolf Steiner

- Rudolf Steiner Archive timeline: https://rsarchive.org/Steiner/Timeline.html
- Rudolf Steiner Archive, The Philosophy of Freedom: https://rsarchive.org/Books/GA004/English/RSP1964/GA004_index.html
- Rudolf Steiner Archive, The Agriculture Course: https://rsarchive.org/Lectures/GA327/English/RSPC1938/
- Frontiers in Education, Waldorf curriculum transformation: https://www.frontiersin.org/journals/education/articles/10.3389/feduc.2024.1306092/full
- Springer, review of biodynamic agriculture research: https://link.springer.com/article/10.1007/s13165-022-00394-2
- National Cancer Institute, mistletoe extracts: https://www.cancer.gov/about-cancer/treatment/cam/hp/mistletoe-pdq
- Staudenmaier, Race and Redemption: https://epublications.marquette.edu/cgi/viewcontent.cgi?article=1078&context=hist_fac

### Transcript Concept Checks

- Bandura self-efficacy overview and mastery-experience discussion: https://www.simplypsychology.org/self-efficacy.html
- Rotter locus of control overview: https://www.simplypsychology.org/locus-of-control.html
- Budner ambiguity tolerance PubMed record: https://pubmed.ncbi.nlm.nih.gov/13874381/
- Schultz dopamine reward prediction error review: https://pubmed.ncbi.nlm.nih.gov/27069377/
- Nature Communications, sperm whale coda structure: https://www.nature.com/articles/s41467-024-47221-8
- Cornell Chronicle, jumping spider sight neurons: https://news.cornell.edu/stories/2014/10/researchers-record-sight-neurons-jumping-spider-brain
- PMC, vertebrate eye evolution: https://pmc.ncbi.nlm.nih.gov/articles/PMC3143066/
