# Local Person Research Room - 2026-05-24

Status: local-only source ore.
Git rule: do not add this folder to Git.
Reason: the user explicitly said files about people should stay off Git because they waste space.

## Purpose

This room holds the deeper Alan Watts, Carl Jung, Rudolf Steiner, and transcript research pass. It is allowed to be detailed and heavy because it is local source custody, not a Git-facing active guide.

The house may later receive only smaller neutral rules if they pass the local source and transcript intake rule:

source ore -> revise pass -> all-angles pass -> evidence gate -> source-safe distilled rule or TODO.

## Read Order

1. SOURCE_LEDGER.md
2. SOURCE_ORE_INTAKE_CARD_TEMPLATE_20260524.md
3. REPORTS\ALAN_WATTS_DEEP_RESEARCH_CAPTURE_20260524.md
4. REPORTS\CARL_GUSTAV_JUNG_DEEP_RESEARCH_CAPTURE_20260524.md
5. REPORTS\RUDOLF_STEINER_DEEP_RESEARCH_CAPTURE_20260524.md
6. TRANSCRIPT_FILES\README_TRANSCRIPT_CUSTODY_20260525.md
7. TRANSCRIPT_NOTES\YT_TRANSCRIPT_FULL_READ_NOTES_AND_BUILD_FIT_20260524.md
8. REPORTS\CREATIVE_ROOM_SYNTHESIS_CONCLUSION_20260524.md
9. LOCAL_ONLY_RECEIPT.md

## Washer Verdict

PASS WITH GUARDRAILS.

The useful triad is:

- Watts: false separation, map-territory, play, non-forcing, archive authenticity.
- Jung: shadow, projection, complex voltage, symbolic integration, synchronicity quarantine.
- Steiner: living-form observation, developmental timing, form-as-function, institution embodiment, evidence split.

Shared warning:

Do not let any person become doctrine. Use lens. Quarantine authority. Preserve source. Extract smaller build rules only after proof.

Applied local tool:

SOURCE_ORE_INTAKE_CARD_TEMPLATE_20260524.md is now the default local card for future people, transcript, and outside-source intake.

Transcript custody update:

The transcript source files are now copied inside this room at TRANSCRIPT_FILES.
